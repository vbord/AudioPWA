﻿/* ============================================================
   Audiobook Player — app.js (final)
   Document scroll disabled — tree scroll only
   Dynamic height — Android safe
   ============================================================ */

const API = "https://slava.localto.net/api/BooksApi";

const treeContainer = document.getElementById("tree-container");
const player = document.getElementById("player");

let userId = null;
let userEmail = null;
let userProgress = {};
let saveTimer = null;

let currentBook = null;
let currentFile = null;

/* ============================================================
   DYNAMIC HEIGHT FOR TREE
   ============================================================ */

function resizeTreeContainer() {
    const header = document.getElementById("header-bar");
    const playerBox = document.getElementById("player-container");

    const headerH = header ? header.offsetHeight : 0;
    const playerH = playerBox ? playerBox.offsetHeight : 0;

    const available = window.innerHeight - headerH - playerH;

    treeContainer.style.height = available + "px";
}

window.addEventListener("load", resizeTreeContainer);
window.addEventListener("resize", resizeTreeContainer);

/* ============================================================
   MENU — Android‑safe scroll freeze
   ============================================================ */

const sideMenu = document.getElementById("side-menu");
const menuBtn = document.getElementById("menu-btn");
const menuCloseBtn = document.getElementById("menu-close-btn");

menuBtn.onclick = () => {
    sideMenu.classList.add("open");
};

menuCloseBtn.onclick = () => {
    sideMenu.classList.remove("open");
};

document.querySelectorAll("#side-menu .menu-item").forEach(btn => {
    btn.addEventListener("click", () => {
        sideMenu.classList.remove("open");
    });
});

/* ============================================================
   PLAYER CONTROL ENABLE/DISABLE
   ============================================================ */

function disablePlayerControls() {
    document.getElementById("btn-back").disabled = true;
    document.getElementById("btn-forward").disabled = true;
    document.getElementById("btn-play").disabled = true;
}

function enablePlayerControls() {
    document.getElementById("btn-back").disabled = false;
    document.getElementById("btn-forward").disabled = false;
    document.getElementById("btn-play").disabled = false;
}

/* ============================================================
   LOADING OVERLAY
   ============================================================ */

function showLoading(msg = "Loading…") {
    const el = document.getElementById("loading-overlay");
    el.textContent = msg;
    el.style.display = "block";
}

function hideLoading() {
    const el = document.getElementById("loading-overlay");
    el.style.display = "none";
}

player.addEventListener("waiting", () => {
    showLoading("Loading…");
    disablePlayerControls();
});

player.addEventListener("canplay", () => {
    hideLoading();
    enablePlayerControls();
});

player.addEventListener("playing", () => {
    hideLoading();
    enablePlayerControls();
});

/* ============================================================
   LOGIN
   ============================================================ */

function showLogin() {
    document.getElementById("login-modal").style.display = "flex";
}

function hideLogin() {
    document.getElementById("login-modal").style.display = "none";
}

document.getElementById("login-btn").onclick = async () => {
    const email = document.getElementById("login-email").value.trim();
    if (!email) return;

    const res = await fetch(`${API}/Login`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email })
    });

    const data = await res.json();
    userId = data.userId;
    userEmail = email;

    localStorage.setItem("ab_userId", userId);
    localStorage.setItem("ab_email", email);

    hideLogin();
    loadProgress();
};

function initLogin() {
    const savedId = localStorage.getItem("ab_userId");
    const savedEmail = localStorage.getItem("ab_email");

    if (savedId && savedEmail) {
        userId = savedId;
        userEmail = savedEmail;
        hideLogin();
        loadProgress();
    } else {
        showLogin();
    }
}

/* ============================================================
   LOAD PROGRESS
   ============================================================ */

async function loadProgress() {
    const res = await fetch(`${API}/GetProgress?userId=${userId}`);
    if (res.ok) {
        const data = await res.json();
        userProgress = data.books || {};
    }
    loadBooks();
}

/* ============================================================
   LOAD BOOK TREE
   ============================================================ */

async function loadBooks() {
    const res = await fetch(`${API}/GetBooks`);
    const books = await res.json();

    const paths = books.map(b => b.name);
    const tree = buildTree(paths);

    treeContainer.innerHTML = "";
    renderTree(tree, treeContainer, "");
}

function buildTree(paths) {
    const root = {};
    paths.forEach(path => {
        const parts = path.split("/");
        let node = root;
        parts.forEach(part => {
            if (!node[part]) node[part] = {};
            node = node[part];
        });
    });
    return root;
}
/* ============================================================
   COVER LOADER
   ============================================================ */

async function loadCover(bookPath) {
    const res = await fetch(`${API}/GetBookCover?book=${encodeURIComponent(bookPath)}`);
    const cover = await res.json();
    if (!cover) return null;
    return `https://slava.localto.net/Uploads/Audio/ABOOKS/${cover}`;
}

/* ============================================================
   TREE RENDERING
   ============================================================ */

function renderTree(node, container, currentPath) {
    Object.keys(node).forEach(key => {
        const fullPath = currentPath ? `${currentPath}/${key}` : key;

        const row = document.createElement("div");
        row.className = "tree-row";

        const arrow = document.createElement("span");
        arrow.className = "arrow";
        arrow.textContent = "►";

        const name = document.createElement("span");
        name.className = "folder-name";
        name.textContent = key;

        const childContainer = document.createElement("div");
        childContainer.className = "tree-node";
        childContainer.style.display = "none";

        const coverImg = document.createElement("img");
        coverImg.className = "book-cover";
        coverImg.style.display = "none";
        childContainer.appendChild(coverImg);

        renderTree(node[key], childContainer, fullPath);

        const mp3Container = document.createElement("div");
        mp3Container.className = "mp3-container";
        childContainer.appendChild(mp3Container);

        arrow.onclick = async () => {
            if (childContainer.style.display === "none") {
                arrow.textContent = "▼";
                childContainer.style.display = "block";

                const coverUrl = await loadCover(fullPath);
                if (coverUrl) {
                    coverImg.src = coverUrl;
                    coverImg.style.display = "block";
                } else {
                    coverImg.style.display = "none";
                }

                loadFilesInto(fullPath, mp3Container);
            } else {
                arrow.textContent = "►";
                childContainer.style.display = "none";
            }
        };

        name.onclick = async () => {
            arrow.textContent = "▼";
            childContainer.style.display = "block";

            const coverUrl = await loadCover(fullPath);
            if (coverUrl) {
                coverImg.src = coverUrl;
                coverImg.style.display = "block";
            } else {
                coverImg.style.display = "none";
            }

            document.querySelectorAll(".file-item").forEach(el => el.remove());
            await loadFilesInto(fullPath, mp3Container);

            setTimeout(() => autoPlayBook(fullPath), 200);
        };

        row.appendChild(arrow);
        row.appendChild(name);
        container.appendChild(row);
        container.appendChild(childContainer);
    });
}

/* ============================================================
   LOAD MP3 FILES
   ============================================================ */

async function loadFilesInto(bookPath, mp3Container) {
    const res = await fetch(`${API}/GetBookFiles?book=${encodeURIComponent(bookPath)}`);
    const files = await res.json();

    mp3Container.innerHTML = "";

    files.forEach(f => {
        const div = document.createElement("div");
        div.className = "file-item";
        div.textContent = f;
        div.dataset.book = bookPath;
        div.dataset.file = f;

        div.onclick = () => playFile(bookPath, f);

        mp3Container.appendChild(div);
    });
}

/* ============================================================
   NOW PLAYING HIGHLIGHT
   ============================================================ */

function markNowPlaying(book, file, opts = { scroll: true }) {
    const items = document.querySelectorAll(".file-item");
    items.forEach(i => i.classList.remove("now-playing-item"));

    const match = [...items].find(i =>
        i.dataset.book === book && i.dataset.file === file
    );

    if (match) {
        match.classList.add("now-playing-item");
        if (opts.scroll) {
            match.scrollIntoView({ behavior: "smooth", block: "center" });
        }
    }
}

/* ============================================================
   PLAYBACK
   ============================================================ */

function playFile(book, file) {
    const url = `https://slava.localto.net/Uploads/Audio/ABOOKS/${book}/${file}`;

    currentBook = book;
    currentFile = file;

    player.src = url;
    player.dataset.book = book;
    player.dataset.file = file;

    const hasSaved =
        userProgress[book] &&
        userProgress[book].file === file &&
        typeof userProgress[book].position === "number" &&
        userProgress[book].position > 0;

    if (hasSaved) {
        showLoading("Loading…");
        disablePlayerControls();

        player.addEventListener("canplay", () => {
            hideLoading();
            enablePlayerControls();
            player.play().catch(() => { });
        }, { once: true });

        player.currentTime = userProgress[book].position;
    } else {
        player.play().catch(() => { });
    }

    markNowPlaying(book, file, { scroll: true });

    document.getElementById("now-playing").textContent =
        `${book} — ${file}`;

    startSaving(book, file);

    player.onended = () => playNextFromDom(file, book);
}

/* ============================================================
   SAVE PROGRESS
   ============================================================ */

function startSaving(book, file) {
    if (saveTimer) clearInterval(saveTimer);

    saveTimer = setInterval(() => {
        saveProgress(book, file, player.currentTime);
    }, 5000);
}

async function saveProgress(book, file, pos) {
    userProgress[book] = { file, position: pos, updated: new Date().toISOString() };

    await fetch(`${API}/SaveProgress`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
            userId,
            book,
            file,
            position: pos
        })
    });
}

/* ============================================================
   CONTINUOUS PLAYBACK
   ============================================================ */

function playNextFromDom(currentFileName, currentBookPath) {
    const items = [...document.querySelectorAll(".file-item")];
    const idx = items.findIndex(el => el.textContent === currentFileName);

    if (idx >= 0 && idx < items.length - 1) {
        items[idx + 1].click();
        return;
    }

    const nextBook = getNextBookPath(currentBookPath);
    if (!nextBook) return;

    setTimeout(() => autoExpandAndPlay(nextBook), 300);
}

function getNextBookPath(currentBookPath) {
    const rows = [...document.querySelectorAll(".tree-row")];
    const names = rows.map(r => r.querySelector(".folder-name").textContent);

    const parts = currentBookPath.split("/");
    const currentName = parts[parts.length - 1];

    const idx = names.indexOf(currentName);
    if (idx === -1) return null;

    if (idx < names.length - 1) {
        return findFullBookPath(names[idx + 1]);
    }

    return findFullBookPath(names[0]);
}

function findFullBookPath(name) {
    const row = [...document.querySelectorAll(".tree-row")]
        .find(r => r.querySelector(".folder-name").textContent === name);

    if (!row) return null;

    let path = name;
    let parent = row.parentElement;

    while (parent && parent.classList.contains("tree-node")) {
        const parentRow = parent.previousElementSibling;
        if (!parentRow) break;

        const parentName = parentRow.querySelector(".folder-name").textContent;
        path = parentName + "/" + path;

        parent = parentRow.parentElement;
    }

    return path;
}

/* ============================================================
   AUTO EXPAND + PLAY
   ============================================================ */

async function autoExpandAndPlay(bookPath) {
    const parts = bookPath.split("/");
    let container = treeContainer;

    for (const part of parts) {
        const row = [...container.querySelectorAll(".tree-row")]
            .find(r => r.querySelector(".folder-name").textContent === part);

        if (!row) continue;

        const arrow = row.querySelector(".arrow");
        const nextContainer = row.nextElementSibling;

        if (nextContainer.style.display === "none") {
            arrow.textContent = "▼";
            nextContainer.style.display = "block";
        }

        container = nextContainer;
    }

    const mp3Container = container.querySelector(".mp3-container");
    if (mp3Container) {
        await loadFilesInto(bookPath, mp3Container);
    }

    const items = [...document.querySelectorAll(".file-item")];
    if (items.length > 0) items[0].click();
}

/* ============================================================
   SEARCH
   ============================================================ */

function searchTree(term, opts = { scroll: true }) {
    term = term.toLowerCase();
    const nodes = document.querySelectorAll("#tree-container .tree-row, #tree-container .file-item");

    let firstMatch = null;

    nodes.forEach(n => {
        n.classList.remove("tree-highlight");

        if (term && n.textContent.toLowerCase().includes(term)) {
            n.classList.add("tree-highlight");
            if (!firstMatch) firstMatch = n;
        }
    });

    if (firstMatch && term && opts.scroll) {
        firstMatch.scrollIntoView({ behavior: "smooth", block: "center" });
    }
}

const searchInput = document.getElementById("tree-search");
const searchBtn = document.getElementById("search-go-btn");

if (searchInput) {
    searchInput.addEventListener("input", () => {
        searchTree(searchInput.value.trim(), { scroll: true });
    });
}

if (searchBtn) {
    searchBtn.onclick = () => {
        searchTree(searchInput.value.trim(), { scroll: true });
    };
}

/* ============================================================
   REFRESH TREE
   ============================================================ */

document.getElementById("refresh-tree-btn").onclick = () => {
    treeContainer.innerHTML = "";
    loadBooks();
};

/* ============================================================
   LOGOUT
   ============================================================ */

document.getElementById("logout-btn").onclick = () => {
    localStorage.removeItem("ab_userId");
    localStorage.removeItem("ab_email");
    location.reload();
};

/* ============================================================
   CLEAR SITE DATA
   ============================================================ */

document.getElementById("clear-site-btn").onclick = async () => {
    localStorage.clear();

    if ("caches" in window) {
        const names = await caches.keys();
        for (const name of names) {
            await caches.delete(name);
        }
    }

    if (navigator.serviceWorker) {
        const regs = await navigator.serviceWorker.getRegistrations();
        for (const reg of regs) {
            await reg.unregister();
        }
    }

    alert("Site data cleared. Reloading…");
    location.reload();
};

/* ============================================================
   INIT
   ============================================================ */

initLogin();
resizeTreeContainer();
